//
//  ViewController.swift
//  Ashtotra Book
//
//  Created by shruthi palchandar on 16/7/19.
//  Copyright © 2019 Shruezee. All rights reserved.
//

import UIKit

class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var tableData = [String]()
    @IBOutlet weak var tableAstotras: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getData()
        self.tableAstotras.tableFooterView = UIView()
        
        self.navigationController?.navigationBar.barTintColor = UIColor.red
    }
    
    func getData() {
        let fileManager = FileManager.default
        let path = Bundle.main.resourcePath!
        
        do {
            let items = try fileManager.contentsOfDirectory(atPath: path)
            
            for item in items {
                if item.contains("pdf") && item.contains("PlainEnglish") {
                    var name = item
                    name = name.replacingOccurrences(of: ".pdf", with: "", options: .literal, range: nil)
                    tableData.append(name)
                }
            }
            DispatchQueue.main.async {
                self.tableAstotras.reloadData()
            }
        } catch {
            print("Failed to read directory")
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ListCell") as? ListCell else { print ("here")
            return UITableViewCell() }
        
        var astotraName = "\(tableData[indexPath.row])"
        
        var imageName = astotraName.components(separatedBy: "_").first ?? "default"
        imageName = imageName.lowercased()
        imageName = "\(imageName)big"
        if let img = UIImage(named: imageName) {
            cell.imgeView?.image = img
        } else {
            cell.imgeView?.image = UIImage(named: "default")
        }
        
        astotraName = astotraName.replacingOccurrences(of: "_", with: " ", options: .literal, range: nil)
        astotraName = astotraName.replacingOccurrences(of: ".pdf", with: "", options: .literal, range: nil)
        astotraName = astotraName.replacingOccurrences(of: "PlainEnglish", with: "", options: .literal, range: nil)
        astotraName = astotraName.replacingOccurrences(of: "Sata", with: "", options: .literal, range: nil)
        astotraName = astotraName.replacingOccurrences(of: "Namavali", with: "", options: .literal, range: nil)
        
        cell.labelAstotraName?.text = astotraName
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedStotra = tableData[indexPath.row]
        DisplayViewController.fileName = selectedStotra
    }
    
}
