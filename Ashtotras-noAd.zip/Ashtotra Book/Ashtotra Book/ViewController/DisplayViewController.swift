//
//  DisplayViewController.swift
//  Ashtotra Book
//
//  Created by shruthi palchandar on 16/7/19.
//  Copyright © 2019 Shruezee. All rights reserved.
//

import UIKit
import PDFKit

class DisplayViewController: UIViewController {
    
    static var fileName = ""
    var selectedLanName = ""
    var currentFileName = ""
    var spinner:UIActivityIndicatorView? = nil
    var pdfView = PDFView(frame: CGRect.zero)
    
    @IBOutlet var segmentedControl: UISegmentedControl!
    
    @IBAction func valueChanged(_ sender: UISegmentedControl) {
        loadPDF(withIndex:sender.selectedSegmentIndex)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        spinner = showLoader(view: self.view)
        
        self.navigationController?.navigationBar.barTintColor = UIColor.red
    }
    
    override func viewDidAppear(_ animated: Bool) {
        setPDFView()
        currentFileName = DisplayViewController.fileName
        loadPDF(withIndex: 0)
        spinner?.dismissLoader()
        setBG()
    }
    
    func setBG() {
        let astotraName = DisplayViewController.fileName
        var imageName = astotraName.components(separatedBy: "_").first ?? "default"
        imageName = imageName.lowercased()
        if let img = UIImage(named: "\(imageName)big") {
            self.view.backgroundColor = UIColor(patternImage: img)
        }
    }
    
    func setPDFView() {
        // Add PDFView to view controller.
        pdfView = PDFView(frame: self.view.bounds)
        pdfView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        let segmentFrame = segmentedControl.frame
        pdfView.frame.origin.y = segmentFrame.origin.y + segmentFrame.size.height
        pdfView.frame.size.height = self.view.frame.height - (segmentFrame.origin.y + segmentFrame.size.height)
        // If View exsist
        for view in self.view.subviews {
            if let subview = view as? PDFView {
                subview.removeFromSuperview()
                break
            }
        }
        pdfView.backgroundColor = UIColor.clear
        self.view.addSubview(pdfView)
        
        // Fit content in PDFView.
        pdfView.autoScales = true
    }
    
    
    func loadPDF(withIndex:Int) {
        switch withIndex {
        case 0:
            currentFileName = currentFileName.replacingOccurrences(of: selectedLanName, with: "PlainEnglish", options: .literal, range: nil)
            selectedLanName = "PlainEnglish"
            break
        case 1:
            currentFileName = currentFileName.replacingOccurrences(of: selectedLanName, with: "Kannada", options: .literal, range: nil)
            selectedLanName = "Kannada"
            break
        case 2:
            currentFileName = currentFileName.replacingOccurrences(of: selectedLanName, with: "Devanagari", options: .literal, range: nil)
            selectedLanName = "Devanagari"
            break
        case 3:
            currentFileName = currentFileName.replacingOccurrences(of: selectedLanName, with: "Telugu", options: .literal, range: nil)
            selectedLanName = "Telugu"
            break
        case 4:
            currentFileName = currentFileName.replacingOccurrences(of: selectedLanName, with: "Tamil", options: .literal, range: nil)
            selectedLanName = "Tamil"
            break
        case 5:
            currentFileName = currentFileName.replacingOccurrences(of: selectedLanName, with: "Gujarati", options: .literal, range: nil)
            selectedLanName = "Gujarati"
            break
            
        default:
            currentFileName = currentFileName.replacingOccurrences(of: selectedLanName, with: "English", options: .literal, range: nil)
            selectedLanName = "English"
        }
        
        // Load Sample.pdf file from app bundle.
        guard let path = Bundle.main.url(forResource: currentFileName, withExtension: "pdf") else {
            print("PDF error")
            return
        }
        
        if let document = PDFDocument(url: path) {
            pdfView.document = document
            pdfView.documentView?.backgroundColor = UIColor.clear
            pdfView.subviews[0].backgroundColor = UIColor.clear
            
        }
    }
    
}
